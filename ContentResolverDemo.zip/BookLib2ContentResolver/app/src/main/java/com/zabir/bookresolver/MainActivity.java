package com.zabir.bookresolver;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView tV;
    private TextView queryTv;
    private Button bookCountBtn;
    private Button insertBtn;
    private Button queryBtn;

    private String COLUMN_BOOK_ID = "bookID";
    private String COLUMN_BOOK_TITLE = "bookTitle";
    private String COLUMN_BOOK_AUTHOR = "bookAuthor";
    private String COLUMN_BOOK_PRICE = "bookPrice";
    private String COLUMN_BOOK_DESCRIPTION = "bookDescription";
    private String COLUMN_BOOK_ISBN = "bookIsbn";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tV = findViewById(R.id.textView_book_count);
        queryTv = findViewById(R.id.textView_query);
        bookCountBtn = findViewById(R.id.button_book_count);
        insertBtn = findViewById(R.id.button_insert);
        queryBtn = findViewById(R.id.button_query);

        Uri uri= Uri.parse("content://fit2081.app.Zabir/books");

//        queryBtn.setOnClickListener(v -> {
//            String[] projection = {"bookId", "bookTitle", "bookAuthor", "bookPrice", "bookDescription", "bookIsbn"};
//            String selection = "bookIsbn=123";
////            String[] selectionArgs = {"123"};
////            String sortOrder = "bookTitle DESC";
//            Cursor result = getContentResolver().query(uri,projection,selection,null,null);
//
//            result.moveToFirst();
//            String titles = "";
//
//            Log.d("BookResolver", "Count: " + result.getCount());
//
//            for (int i = 0; i < result.getCount(); i++) {
//                titles += result.getString(result.getColumnIndex("bookTitle")) + "; ";
//                Log.d("BookResolver", titles);
//                result.moveToNext();
//            }
//
//            queryTv.setText("Title: " + titles);
//        });


        queryBtn.setOnClickListener(v -> {
            String[] projection = {COLUMN_BOOK_ID, COLUMN_BOOK_TITLE, COLUMN_BOOK_AUTHOR, COLUMN_BOOK_ISBN, COLUMN_BOOK_DESCRIPTION, COLUMN_BOOK_PRICE};
            String selection = COLUMN_BOOK_ISBN + "=12345";
//            String[] selectionArgs = {"50"};

            Cursor result = getContentResolver().query(uri, projection, selection, null,null);
            queryTv.setText("Number of books with ISBN 12345: " + result.getCount());
        });

        // the insert method needs the data of the new row to be wrapped(inside) by ContentValues class.
        insertBtn.setOnClickListener(v -> {
            ContentValues values = new ContentValues();
            values.put(COLUMN_BOOK_TITLE, "Book 3");
            values.put(COLUMN_BOOK_AUTHOR, "Author 3");
            values.put(COLUMN_BOOK_ISBN, "123");
            values.put(COLUMN_BOOK_PRICE, 13.0);
            values.put(COLUMN_BOOK_DESCRIPTION, "Description 2");
            getContentResolver().insert(uri, values);
            Toast.makeText(this, "New Book Inserted", Toast.LENGTH_SHORT).show();
        });

        bookCountBtn.setOnClickListener(v -> {
//            Cursor result= getContentResolver().query(uri,null,null,null);
//            tV.setText("Number of books: " + result.getCount());
//             show count of books with price > 12
            String[] projection = {COLUMN_BOOK_ID, COLUMN_BOOK_TITLE, COLUMN_BOOK_AUTHOR, COLUMN_BOOK_ISBN, COLUMN_BOOK_DESCRIPTION, COLUMN_BOOK_PRICE};
            String selection = COLUMN_BOOK_PRICE + ">12";
//            String[] selectionArgs = {"12"};
            Cursor result = getContentResolver().query(uri, projection, selection, null,null);
            tV.setText("Number of books: " + result.getCount());

        });
    }
}